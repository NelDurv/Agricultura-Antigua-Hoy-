/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  GraduationCap, 
  ArrowLeft, 
  BookOpen, 
  CheckCircle, 
  CheckCircle2, 
  PlayCircle, 
  Award, 
  ChevronRight, 
  Lock, 
  BookOpenCheck,
  AlertCircle,
  HelpCircle
} from "lucide-react";
import { COURSES } from "../data";
import { Course, Module, Certificate } from "../types";

interface AcademiaSectionProps {
  enrolledCourses: string[];
  courseProgress: { [courseId: string]: number };
  completedModules: string[];
  onEnroll: (courseId: string) => void;
  onCompleteModule: (courseId: string, moduleId: string, progressValue: number) => void;
  onAddCertificate: (cert: Certificate) => void;
  userName: string;
  initialCourseId?: string;
}

export default function AcademiaSection({
  enrolledCourses,
  courseProgress,
  completedModules,
  onEnroll,
  onCompleteModule,
  onAddCertificate,
  userName,
  initialCourseId
}: AcademiaSectionProps) {
  // If we came from an external navigation link to a specific course
  const [activeCourseId, setActiveCourseId] = useState<string | null>(initialCourseId || null);
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null);

  // Sync initialCourseId if it changes from navigation
  React.useEffect(() => {
    if (initialCourseId) {
      setActiveCourseId(initialCourseId);
      const course = COURSES.find(c => c.id === initialCourseId);
      if (course) {
        setActiveModuleId(course.modules[0].id);
      }
    }
  }, [initialCourseId]);
  
  // Interactive quiz state
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizChecked, setQuizChecked] = useState(false);
  const [quizSuccess, setQuizSuccess] = useState<boolean | null>(null);

  const activeCourse = COURSES.find(c => c.id === activeCourseId);

  // Auto select first module if inside a course workspace
  React.useEffect(() => {
    if (activeCourse && !activeModuleId) {
      setActiveModuleId(activeCourse.modules[0].id);
    }
  }, [activeCourse, activeModuleId]);

  // Handle quiz reset when changing module
  React.useEffect(() => {
    setSelectedAnswer(null);
    setQuizChecked(false);
    setQuizSuccess(null);
  }, [activeModuleId]);

  const handleEnrollClick = (courseId: string) => {
    onEnroll(courseId);
    setActiveCourseId(courseId);
    const course = COURSES.find(c => c.id === courseId);
    if (course) {
      setActiveModuleId(course.modules[0].id);
    }
  };

  const handleMarkCompleted = (course: Course, module: Module) => {
    const totalModules = course.modules.length;
    
    // Find how many modules are completed after this one
    const newCompleted = new Set(completedModules);
    newCompleted.add(module.id);
    
    const courseModules = course.modules.map(m => m.id);
    const completedInThisCourse = courseModules.filter(id => newCompleted.has(id)).length;
    const progressPercentage = Math.round((completedInThisCourse / totalModules) * 100);

    onCompleteModule(course.id, module.id, progressPercentage);

    // Auto navigate to next module if available
    const currentIndex = course.modules.findIndex(m => m.id === module.id);
    if (currentIndex < totalModules - 1) {
      setActiveModuleId(course.modules[currentIndex + 1].id);
    }
  };

  const handleCheckQuiz = (module: Module) => {
    if (selectedAnswer === null || !module.quiz) return;
    setQuizChecked(true);
    const correct = selectedAnswer === module.quiz.correctAnswer;
    setQuizSuccess(correct);
  };

  const handleGenerateCertificate = (course: Course) => {
    const uniqueCode = `AA-2026-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    const cert: Certificate = {
      id: `cert-${course.id}-${Date.now()}`,
      courseId: course.id,
      courseTitle: course.title,
      date: new Date().toLocaleDateString("es-ES", { year: "numeric", month: "long", day: "numeric" }),
      code: uniqueCode,
      recipientName: userName || "Estudiante de Agricultura Antigua"
    };
    onAddCertificate(cert);
    alert(`¡Felicidades ${userName}! Se ha generado tu certificado oficial para "${course.title}". Ya puedes consultarlo o descargarlo en la pestaña 'Mi Perfil'.`);
  };

  const getModuleIcon = (type: string, isCompleted: boolean) => {
    if (isCompleted) {
      return <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />;
    }
    switch (type) {
      case "lecture":
        return <BookOpen className="h-4 w-4 text-stone-400 shrink-0" />;
      case "practical":
        return <PlayCircle className="h-4 w-4 text-emerald-600 shrink-0" />;
      case "quiz":
        return <HelpCircle className="h-4 w-4 text-amber-500 shrink-0" />;
      default:
        return <BookOpen className="h-4 w-4 text-stone-400 shrink-0" />;
    }
  };

  // If inside the workspace of an enrolled course
  if (activeCourse && enrolledCourses.includes(activeCourse.id)) {
    const progress = courseProgress[activeCourse.id] || 0;
    const currentModule = activeCourse.modules.find(m => m.id === activeModuleId) || activeCourse.modules[0];
    const isCompleted = completedModules.includes(currentModule.id);

    return (
      <div className="space-y-6 py-4" id="academia-workspace">
        {/* Workspace Nav Header */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between border-b border-stone-200 pb-4">
          <button
            onClick={() => setActiveCourseId(null)}
            className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900"
            id="back-to-academy-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Volver a la Academia</span>
          </button>
          
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] font-mono uppercase text-stone-400">Progreso del curso</p>
              <p className="text-xs font-bold text-stone-900">{progress}% Completado</p>
            </div>
            {/* Progress Bar */}
            <div className="w-full sm:w-32 h-2.5 bg-stone-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-600 transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Workspace Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Left Column: Modules Index */}
          <div className="lg:col-span-1 bg-stone-50 border border-stone-200 rounded-2xl p-4 space-y-4">
            <div>
              <h4 className="font-serif text-sm font-bold text-stone-900 line-clamp-1">{activeCourse.title}</h4>
              <p className="text-[10px] text-stone-400 mt-0.5">{activeCourse.author}</p>
            </div>

            <div className="space-y-1">
              {activeCourse.modules.map((mod, idx) => {
                const modCompleted = completedModules.includes(mod.id);
                const isSelected = activeModuleId === mod.id;
                
                return (
                  <button
                    key={mod.id}
                    onClick={() => setActiveModuleId(mod.id)}
                    className={`w-full text-left p-3 rounded-xl flex items-start gap-3 transition-colors ${
                      isSelected
                        ? "bg-emerald-50 border border-emerald-200 text-emerald-900 font-medium"
                        : "hover:bg-stone-100/80 border border-transparent text-stone-600"
                    }`}
                  >
                    <span className="text-[10px] font-mono mt-0.5 text-stone-400">0{idx + 1}</span>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center justify-between gap-1.5">
                        <p className={`text-[11px] leading-tight font-serif font-semibold truncate ${isSelected ? "text-emerald-950" : "text-stone-800"}`}>
                          {mod.title}
                        </p>
                        {getModuleIcon(mod.type, modCompleted)}
                      </div>
                      <span className="text-[9px] font-mono text-stone-400 uppercase tracking-wide">{mod.type === "lecture" ? "Teoría" : mod.type === "practical" ? "Práctica" : "Evaluación"} • {mod.duration}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Certificate generation if 100% */}
            {progress === 100 && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3 text-center">
                <Award className="h-7 w-7 text-amber-600 mx-auto" />
                <div>
                  <h5 className="font-serif text-xs font-bold text-amber-900">¡Capacitación Completada!</h5>
                  <p className="text-[10px] text-amber-800 mt-1 leading-snug">Ya cumples con todos los módulos y pruebas. Obtén tu certificado con registro oficial en este instante.</p>
                </div>
                <button
                  onClick={() => handleGenerateCertificate(activeCourse)}
                  className="w-full py-1.5 bg-amber-600 hover:bg-amber-700 text-stone-50 text-[10px] font-bold rounded-lg transition-colors inline-flex items-center justify-center gap-1 shadow-xs"
                >
                  <Award className="h-3.5 w-3.5" />
                  <span>Obtener Certificado</span>
                </button>
              </div>
            )}
          </div>

          {/* Right Column: Module Viewer Workspace */}
          <div className="lg:col-span-3 bg-stone-50 border border-stone-200 rounded-2xl p-6 sm:p-8 space-y-6 flex flex-col justify-between min-h-[450px]">
            <div className="space-y-4">
              <div className="border-b border-stone-200 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-mono text-emerald-800 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded font-semibold uppercase tracking-wide">
                    {currentModule.type === "lecture" ? "Módulo de Teoría" : currentModule.type === "practical" ? "Módulo de Campo Práctico" : "Evaluación de Competencia"}
                  </span>
                  <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 mt-1.5">{currentModule.title}</h3>
                </div>
                <span className="text-xs text-stone-400 font-mono">Duración estimada: {currentModule.duration}</span>
              </div>

              {/* Module Content */}
              {currentModule.type !== "quiz" ? (
                <div className="space-y-4 text-stone-800 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                  {currentModule.content}
                </div>
              ) : (
                <div className="space-y-6 bg-white p-5 rounded-xl border border-stone-100">
                  <p className="text-sm text-stone-700 leading-normal font-sans">
                    {currentModule.content}
                  </p>
                  
                  {currentModule.quiz && (
                    <div className="space-y-3">
                      <p className="text-xs font-mono text-stone-400 uppercase tracking-wider font-semibold">Pregunta de Evaluación:</p>
                      <h4 className="font-serif text-sm font-bold text-stone-900 leading-snug">{currentModule.quiz.question}</h4>
                      
                      <div className="space-y-2 mt-3">
                        {currentModule.quiz.options.map((opt, oIdx) => (
                          <label
                            key={oIdx}
                            className={`w-full p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all text-xs ${
                              selectedAnswer === oIdx
                                ? "bg-stone-50 border-emerald-500 font-medium"
                                : "hover:bg-stone-50 border-stone-200"
                            }`}
                          >
                            <input
                              type="radio"
                              name="quiz-opt"
                              checked={selectedAnswer === oIdx}
                              onChange={() => {
                                if (!quizChecked) setSelectedAnswer(oIdx);
                              }}
                              disabled={quizChecked}
                              className="mt-0.5 h-3.5 w-3.5 text-emerald-600 focus:ring-emerald-500 border-stone-300"
                            />
                            <span className="text-stone-800 leading-normal">{opt}</span>
                          </label>
                        ))}
                      </div>

                      {/* Quiz Feedback block */}
                      {quizChecked && (
                        <div className={`p-4 rounded-xl flex items-start gap-2.5 text-xs ${
                          quizSuccess 
                            ? "bg-emerald-50 border border-emerald-200 text-emerald-800" 
                            : "bg-red-50 border border-red-200 text-red-800"
                        }`}>
                          {quizSuccess ? (
                            <>
                              <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0" />
                              <div>
                                <p className="font-bold">¡Excelente respuesta!</p>
                                <p className="mt-0.5 leading-normal">Has captado perfectamente el núcleo del contenido técnico. Puedes avanzar al siguiente módulo.</p>
                              </div>
                            </>
                          ) : (
                            <>
                              <AlertCircle className="h-4.5 w-4.5 text-red-600 shrink-0" />
                              <div>
                                <p className="font-bold">Respuesta incorrecta</p>
                                <p className="mt-0.5 leading-normal">Te recomendamos volver a leer detenidamente el módulo teórico anterior sobre este tema e intentarlo de nuevo.</p>
                                <button
                                  onClick={() => {
                                    setQuizChecked(false);
                                    setSelectedAnswer(null);
                                    setQuizSuccess(null);
                                  }}
                                  className="mt-2 text-red-900 font-bold hover:underline"
                                >
                                  Reintentar Evaluación
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      )}

                      {!quizChecked && (
                        <button
                          onClick={() => handleCheckQuiz(currentModule)}
                          disabled={selectedAnswer === null}
                          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-stone-50 text-xs font-semibold rounded-lg transition-all"
                        >
                          Verificar Respuesta
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Complete Module Button and Actions */}
            <div className="pt-6 border-t border-stone-200 flex items-center justify-between mt-8">
              <span className="text-xs text-stone-500 font-mono">
                {isCompleted ? (
                  <span className="text-emerald-700 font-medium flex items-center gap-1">
                    <CheckCircle className="h-4 w-4 inline" /> Lección completada
                  </span>
                ) : (
                  "Módulo pendiente de aprobación"
                )}
              </span>

              {/* Only show Mark complete for lectures, or when quiz is successful */}
              {(currentModule.type !== "quiz" || (quizChecked && quizSuccess)) && (
                <button
                  onClick={() => handleMarkCompleted(activeCourse, currentModule)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-stone-50 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <span>{isCompleted ? "Continuar" : "Marcar como Completado"}</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // General Academy Landing
  return (
    <div className="space-y-8 py-4" id="academia-landing">
      {/* Header */}
      <div className="space-y-2">
        <span className="font-mono text-[10px] text-emerald-700 tracking-wider uppercase font-semibold">Formación Profesional</span>
        <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">Academia Agricultura Antigua</h2>
        <p className="text-xs text-stone-600 max-w-2xl">
          Nuestra aula virtual ofrece metodologías prácticas probadas en campo. Todos los cursos son guiados por especialistas en agroecología, con evaluaciones por competencia y emisión de certificados respaldados.
        </p>
      </div>

      <div className="space-y-6">
        <h3 className="text-xs font-mono tracking-wider text-stone-500 uppercase font-semibold">Oferta Académica</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {COURSES.map((course) => {
            const isEnrolled = enrolledCourses.includes(course.id);
            const progress = courseProgress[course.id] || 0;

            return (
              <div 
                key={course.id}
                className="bg-stone-50 border border-stone-200 rounded-2xl p-5 flex flex-col justify-between hover:shadow-md transition-all space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-semibold border border-emerald-100 uppercase">
                      {course.category}
                    </span>
                    {course.isPremium && (
                      <span className="inline-flex items-center gap-0.5 bg-amber-50 text-amber-900 text-[9px] font-mono font-semibold px-2 py-0.5 rounded border border-amber-200">
                        <Lock className="h-2.5 w-2.5 inline" /> Premium
                      </span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <h4 className="font-serif text-base font-bold text-stone-950 leading-tight">
                      {course.title}
                    </h4>
                    <p className="text-xs text-stone-500">Impartido por: {course.author}</p>
                  </div>

                  <p className="text-xs text-stone-600 leading-relaxed">
                    {course.description}
                  </p>

                  <div className="pt-2 flex items-center justify-between text-[11px] font-mono text-stone-400">
                    <span>Nivel: <strong className="text-stone-700 font-semibold">{course.level}</strong></span>
                    <span>Duración: <strong className="text-stone-700 font-semibold">{course.duration}</strong></span>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200 space-y-3">
                  {/* Show Progress indicator if enrolled */}
                  {isEnrolled && (
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-stone-400">Progreso del curso</span>
                        <span className="text-emerald-700 font-bold">{progress}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-stone-200 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-600" style={{ width: `${progress}%` }}></div>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-1 text-xs">
                      <span className="text-amber-500">★</span>
                      <strong className="text-stone-700">{course.rating}</strong>
                    </div>

                    {isEnrolled ? (
                      <button
                        onClick={() => {
                          setActiveCourseId(course.id);
                          // select first incomplete module or first module
                          const nextIncomplete = course.modules.find(m => !completedModules.includes(m.id)) || course.modules[0];
                          setActiveModuleId(nextIncomplete.id);
                        }}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-stone-50 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <span>{progress === 100 ? "Ver Aula / Certificado" : "Continuar Curso"}</span>
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    ) : (
                      <button
                        onClick={() => handleEnrollClick(course.id)}
                        className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <span>Inscribirse Gratis</span>
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
