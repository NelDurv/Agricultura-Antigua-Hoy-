/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Course, BibliotecaDoc, CommunityPost, Pilar, Mito, CasoExito, NumeroClave, Receta, GlosarioItem, SubtemasMap } from "./types";

export const COURSES: Course[] = [
  {
    id: "suelo-vivo",
    title: "Suelo Vivo: Microbiología y Regeneración",
    description: "Aprende a diagnosticar, activar y multiplicar la vida microscópica del suelo para una nutrición vegetal óptima.",
    extendedDescription: "Este curso práctico enseña los fundamentos del suelo como un organismo vivo. Aprenderás a transitar de una agricultura dependiente de agroquímicos a un sistema regenerativo basado en la microbiología autóctona, reduciendo costos de producción y aumentando la resiliencia climática.",
    level: "Principiante",
    category: "Nutrición de Suelos",
    duration: "12 horas",
    lessonsCount: 4,
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c3aa?auto=format&fit=crop&q=80&w=600",
    rating: 4.9,
    isPremium: false,
    author: "Ing. Alejandro Salazar - Especialista en Microbiología de Suelos",
    modules: [
      {
        id: "sv-m1",
        title: "La red alimentaria del suelo y sus actores",
        duration: "3h",
        type: "lecture",
        content: "El suelo no es un soporte inerte; es un ecosistema complejo habitado por miles de millones de bacterias, hongos micorrízicos, nematodos, protozoos y artrópodos. Estos organismos trabajan en conjunto para mineralizar nutrientes, crear estructura de agregados estables, regular el agua y defender a las plantas contra patógenos. La fotosíntesis de la planta alimenta este ecosistema subterráneo mediante exudados radiculares (azúcares, aminoácidos y ácidos orgánicos), creando una simbiosis perfecta donde el suelo vivo alimenta a la planta a cambio de energía solar."
      },
      {
        id: "sv-m2",
        title: "Evaluación visual de la salud del suelo (Prueba de Campo)",
        duration: "3h",
        type: "practical",
        content: "Aprende a realizar un diagnóstico cualitativo rápido en campo sin necesidad de costosos equipos de laboratorio. 1) Prueba de la pala: extrae un cubo de tierra de 20x20 cm y observa la porosidad, el color oscuro (indicador de humus) y la estructura (si se desmorona en agregados redondeados como granola o está compactada). 2) Conteo de lombrices: más de 5 lombrices por palada indica excelente actividad biológica. 3) Prueba de olor: un suelo sano huele a bosque húmedo (geosmina); un suelo enfermo huele a podrido o carece de olor. 4) Prueba de estabilidad de agregados en agua (Slake Test) para medir la resistencia a la erosión hídrica."
      },
      {
        id: "sv-m3",
        title: "Cuestionario: Fundamentos microbiológicos",
        duration: "2h",
        type: "quiz",
        content: "Pon a prueba tus conocimientos sobre la red trófica del suelo, las funciones del humus y los métodos de diagnóstico físico-químico rústicos.",
        quiz: {
          question: "¿Cuál es el principal motor biológico que alimenta a los microorganismos en la rizosfera?",
          options: [
            "Las lluvias y los minerales disueltos en el agua subterránea.",
            "Los exudados radiculares liberados por las raíces de las plantas durante la fotosíntesis.",
            "Las sales contenidas en los fertilizantes químicos tradicionales.",
            "La radiación ultravioleta directa sobre la superficie desprovista de cobertura."
          ],
          correctAnswer: 1
        }
      },
      {
        id: "sv-m4",
        title: "Plan de transición: de convencional a orgánico",
        duration: "4h",
        type: "practical",
        content: "Pasos prácticos para desintoxicar un terreno agrícola degradado por labranza pesada y agroquímicos. Paso 1: Establecer coberturas vegetales de leguminosas y gramíneas para reactivar la fotosíntesis continua. Paso 2: Reducir gradualmente el uso de nitrógeno soluble en un 30% anual aplicando simultáneamente compost o biofertilizante foliar. Paso 3: Eliminar el volteo profundo del suelo mediante el uso de arado de cincel o herramientas manuales como la laya de doble mango para mantener la estratificación natural de la microbiota."
      }
    ]
  },
  {
    id: "biofertilizantes",
    title: "Biofertilizantes y Caldos Minerales",
    description: "Crea tus propios bioinsumos líquidos y pastas protectoras de bajo costo utilizando recursos locales de tu finca.",
    extendedDescription: "Aprende a formular y fermentar caldos nutricionales y protectores. En este curso de carácter 100% práctico, te enseñamos paso a paso a elaborar recetas tradicionales como el caldo sulfocálcico, el súper magro y caldos fermentados anaeróbicos que devuelven la salud a tus cultivos por una fracción del costo comercial.",
    level: "Principiante",
    category: "Preparación de Bioinsumos",
    duration: "10 horas",
    lessonsCount: 3,
    image: "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?auto=format&fit=crop&q=80&w=600",
    rating: 4.8,
    isPremium: false,
    author: "Dra. Elena Rivera - Investigadora de Agroecología Aplicada",
    modules: [
      {
        id: "bf-m1",
        title: "Fermentación anaeróbica: El Caldo Súper Magro",
        duration: "4h",
        type: "lecture",
        content: "El Caldo Súper Magro es un fertilizante orgánico líquido enriquecido con micronutrientes fermentado de forma anaeróbica (sin oxígeno). El núcleo base consiste en estiércol fresco de vaca, agua, melaza de caña (fuente de energía) y leche o suero (fuente de inóculo bacteriano de lactobacilos). A esta mezcla se le añaden paulatinamente sales minerales disueltas (sulfato de zinc, sulfato de cobre, sulfato de magnesio, bórax) que sufren un proceso de quelatación biológica, convirtiendo metales pesados en compuestos orgánicos altamente asimilables para las plantas. El sistema requiere una trampa de agua con una manguera conectada a la tapa del bidón para evacuar el dióxido de carbono y gas metano sin permitir la entrada de aire exterior."
      },
      {
        id: "bf-m2",
        title: "Cuestionario: Química orgánica de los caldos",
        duration: "2h",
        type: "quiz",
        content: "Evalúa los fundamentos físicos y biológicos de la fermentación y la preparación segura de bioinsumos.",
        quiz: {
          question: "¿Por qué es crucial el uso de una trampa de agua en el bidón de fermentación del Caldo Súper Magro?",
          options: [
            "Para evitar que el fertilizante se evapore por completo.",
            "Para permitir la salida segura de gases de fermentación (CO2) e impedir el ingreso de oxígeno que arruinaría la fermentación anaeróbica.",
            "Para filtrar el mal olor e introducir microorganismos del aire ambiente.",
            "Para acelerar el calentamiento térmico de la mezcla hasta los 70 grados centígrados."
          ],
          correctAnswer: 1
        }
      },
      {
        id: "bf-m3",
        title: "Elaboración de Caldo Sulfocálcico y Pasta Bordelesa",
        duration: "4h",
        type: "practical",
        content: "Guía práctica de cocción de azufre y cal para el control preventivo de ácaros y hongos fitopatógenos (como cenicilla y roya). Receta: Hierve en un recipiente metálico (nunca de aluminio) 10 litros de agua limpia. Agrega lentamente 2 kg de azufre elemental molido mezclado previamente con 1 kg de cal viva o cal hidratada de alta pureza. Cocina a fuego fuerte durante 45 a 60 minutos agitando constantemente con un palo de madera, hasta que el líquido tome un color ámbar o 'ladrillo' intenso. Deja enfriar, filtra las impurezas y almacena en envases plásticos oscuros y herméticos. Se diluye entre el 1% y 2% para aplicaciones foliares preventivas."
      }
    ]
  },
  {
    id: "bokashi-avanzado",
    title: "Abonos Fermentados tipo Bokashi",
    description: "Domina el arte del compostaje rápido japonés modificado para climas tropicales y templados.",
    extendedDescription: "El Bokashi es una de las técnicas de reciclaje orgánico más rápidas del mundo, lista para usarse en menos de 15 días. Este curso avanzado profundiza en el control de temperatura, balance de carbono/nitrógeno e inoculación de levaduras y actinobacterias para producir un fertilizante sólido de la más alta calidad biológica.",
    level: "Intermedio",
    category: "Nutrición de Suelos",
    duration: "15 horas",
    lessonsCount: 3,
    image: "https://images.unsplash.com/photo-1592150621744-aca64f48394a?auto=format&fit=crop&q=80&w=600",
    rating: 4.9,
    isPremium: true,
    author: "MSc. Kenji Takahashi - Agrónomo y Asesor de Permacultura",
    modules: [
      {
        id: "bk-m1",
        title: "La termofilia y microbiología del Bokashi",
        duration: "5h",
        type: "lecture",
        content: "A diferencia del compostaje tradicional que toma meses, el Bokashi se elabora en 12 a 15 días mediante un proceso fermentativo de alta temperatura controlado por volteos diarios. Los ingredientes básicos son: afrechillo o salvado de arroz (fuente de nitrógeno y vitaminas), cascarilla de arroz o carbón molido (fuente de silicio, aireación y retención de humedad), tierra común, estiércol, melaza y levadura de pan o microorganismos de montaña. Durante los primeros 3 días, las levaduras y bacterias ácido-lácticas metabolizan azúcares simples elevando la temperatura hasta los 65°C. Esto elimina patógenos y semillas de malezas. Los volteos diarios evitan que la temperatura supere los 75°C, lo que mataría a los microorganismos benéficos y causaría pérdida de nitrógeno por volatilización."
      },
      {
        id: "bk-m2",
        title: "Cálculo de Relación Carbono:Nitrógeno (C:N)",
        duration: "4h",
        type: "practical",
        content: "Para un Bokashi perfecto, la relación ideal C:N debe rondar entre 25:1 y 30:1 al inicio del proceso. Si hay demasiado nitrógeno (ej. exceso de estiércol fresco u orina), la pila olerá a amoníaco y se perderán nutrientes valiosos en forma de gas. Si hay demasiado carbono (ej. exceso de paja seca o aserrín viejo de madera), el proceso se ralentizará enormemente y no alcanzará las temperaturas sanitizantes deseadas. Aprende a equilibrar tu pila combinando fuentes verdes húmedas con fuentes cafés secas mediante la prueba empírica del puño: al apretar fuertemente un puñado de la mezcla terminada, no debe gotear agua entre los dedos, pero al abrir la mano la mezcla debe mantener su cohesión sin desmoronarse."
      },
      {
        id: "bk-m3",
        title: "Cuestionario de Control de Temperatura",
        duration: "6h",
        type: "quiz",
        content: "Examen sobre termorregulación, corrección de desviaciones anaeróbicas y estabilización del abono fermentado.",
        quiz: {
          question: "¿Cuál es la acción correctiva inmediata si la temperatura de tu pila de Bokashi supera los 70°C al cuarto día?",
          options: [
            "Agregar agua fría directamente sobre la pila sin moverla.",
            "Realizar un volteo inmediato de la pila para ventilar e irradiar el exceso de calor acumulado.",
            "Tapar herméticamente la pila con plástico negro para asfixiar los microorganismos.",
            "Agregar más estiércol de ave fresco para estabilizar el ph."
          ],
          correctAnswer: 1
        }
      }
    ]
  }
];

export const BIBLIOTECA: BibliotecaDoc[] = [
  {
    id: "ficha-compostaje-domestico",
    title: "Guía de Parámetros Críticos en Compostaje",
    category: "Fichas Técnicas",
    subcategory: "Monitoreo y Control",
    difficulty: "Bajo",
    cultivo: "Policultivos, Huertos Familiares",
    author: "Centro de Investigación Agroecológica de Agricultura Antigua",
    date: "12 de Mayo de 2026",
    version: "v1.4",
    licencia: "Creative Commons BY-NC-SA 4.0",
    tags: ["Compost", "Suelos", "Humedad", "Temperatura", "Ficha Técnica"],
    description: "Parámetros óptimos para asegurar una descomposición aeróbica rápida sin malos olores. Incluye rangos óptimos de temperatura, humedad, relación C:N y pH.",
    fullText: "El compostaje exitoso depende del control estricto de cuatro factores biofísicos: \n\n" +
              "1. TEMPERATURA: El proceso atraviesa tres etapas. Etapa mesófila (20-40°C, primeros días), etapa termófila (45-65°C, desinfección de patógenos y malezas), y etapa de maduración (vuelta a temperatura ambiente). La fase termófila debe sostenerse por al menos 3 días consecutivos a más de 55°C para garantizar inocuidad. \n\n" +
              "2. HUMEDAD: El rango óptimo es de 50% a 60%. Si cae por debajo de 40%, la actividad microbiana se detiene. Si supera el 65%, el agua desplaza al aire de los poros de la pila, desatando una fermentación anaeróbica ácida causante de malos olores y lixiviación de nutrientes. \n\n" +
              "3. AIREACIÓN: El oxígeno es el combustible de los hongos y bacterias aeróbicas. Debe garantizarse mediante volteos periódicos o la inserción de tubos perforados en el núcleo de la pila. \n\n" +
              "4. RELACIÓN C:N: La mezcla ideal de arranque debe tener 30 partes de Carbono por 1 de Nitrógeno. Fuentes ricas en nitrógeno (verdes): restos de verdura, estiércol fresco, césped cortado. Fuentes ricas en carbono (cafés): hojas secas, paja, cartón picado, aserrín limpio.",
    downloads: 1420,
    relatedCourses: ["suelo-vivo"],
    sources: [
      "FAO (2020) Manual de Compostaje del Agricultor",
      "Universidad Nacional Agraria - Laboratorio de Biología de Suelos"
    ]
  },
  {
    id: "protocolo-microorganismos-montana",
    title: "Protocolo de Captura y Multiplicación de Microorganismos de Montaña (MM)",
    category: "Protocolos",
    subcategory: "Inoculantes Biológicos",
    difficulty: "Medio",
    cultivo: "General",
    author: "Colectivo Regenerativo de Agricultura Antigua",
    date: "04 de Enero de 2026",
    version: "v2.1",
    licencia: "GPLv3 Open Source",
    tags: ["MM", "Microbiología", "Inóculo", "Montaña", "Protocolo"],
    description: "Método paso a paso para colectar hojarasca colonizada por hongos benéficos del bosque nativo y multiplicarlos de forma sólida y líquida para la salud del cultivo.",
    fullText: "Los Microorganismos de Montaña (MM) constituyen un inóculo complejo que estabiliza el suelo y mejora la absorción radicular. \n\n" +
              "FASE 1: CAPTURA (Fase Sólida)\n" +
              "Se acude a un bosque saludable y se colecta la hojarasca semi-descompuesta impregnada de un manto blanco filamentoso (micelio). Se mezclan 40 kg de este mantillo forestal con 40 kg de salvado de trigo o arroz y 20 litros de melaza diluida en suero o agua de lluvia. Se humedece homogéneamente (prueba del puño). Se compacta fuertemente en un bidón plástico de 200 litros asegurando que no quede aire atrapado en las capas. Se sella herméticamente y se deja fermentar por 30 días a la sombra.\n\n" +
              "FASE 2: ACTIVACIÓN (Fase Líquida)\n" +
              "Transcurridos los 30 días, el contenido sólido debe oler a fermento dulce-ácido agradable. Para activarlo en forma líquida, se introducen 4 kg del MM sólido en un saco de tela permeable (como un té gigante) y se sumerge en un bidón de 200L lleno de agua limpia, 4L de melaza y 4L de suero láctico. Se sella anaeróbicamente por 15 a 20 días. El líquido resultante se aplica foliar al 5-10% o al suelo mediante sistema de riego por goteo.",
    downloads: 2150,
    relatedCourses: ["suelo-vivo", "biofertilizantes"],
    sources: [
      "Experiencias de Agricultura Orgánica en Costa Rica - Jairo Restrepo Rivera",
      "Estudio de Viabilidad Microbiana de Suelos Tropicales, INTA."
    ]
  },
  {
    id: "guia-bioestimulantes-foliares",
    title: "Guía de Aplicación Eficiente de Bioestimulantes de Crecimiento",
    category: "Guías",
    subcategory: "Fisiología Vegetal",
    difficulty: "Bajo",
    cultivo: "Hortalizas, Frutales",
    author: "Dra. Elena Rivera",
    date: "30 de Marzo de 2026",
    version: "v1.0",
    licencia: "Creative Commons BY-NC",
    tags: ["Bioestimulantes", "Aplicación", "Foliar", "Nutrición"],
    description: "Tiempos, condiciones meteorológicas y dosificaciones clave para maximizar la absorción foliar a través de los estomas vegetales.",
    fullText: "Para que un fertilizante o bioestimulante foliar sea efectivo, debe atravesar la cutícula de las hojas e ingresar a las células de las plantas a través de los estomas. \n\n" +
              "1. HORA DE APLICACIÓN: Aplica únicamente en las primeras horas de la mañana (de 6:00 AM a 9:00 AM) o en las últimas horas de la tarde (después de las 5:00 PM). A estas horas la temperatura ambiental es baja y la humedad relativa es alta, lo que estimula la apertura de los estomas vegetales. Evita el mediodía: la alta radiación cierra estomas para conservar agua, y las gotas de aspersión actúan como lupa quemando el tejido foliar. \n\n" +
              "2. PH DEL AGUA: El agua de aspersión debe tener un pH ligeramente ácido (entre 5.5 y 6.5). El agua alcalina de pozo con pH de 8.0 neutraliza la asimilación de micronutrientes como el hierro y el zinc. Se puede acidificar el agua añadiendo 1-2 ml de vinagre común por litro de agua. \n\n" +
              "3. COBERTURA: Recuerda mojar abundantemente el envés (parte inferior) de las hojas. El envés contiene hasta 10 veces más densidad de estomas que el haz (parte superior), aumentando drásticamente la tasa de absorción de tus caldos biológicos.",
    downloads: 980,
    relatedCourses: ["biofertilizantes"],
    sources: [
      "Taiz & Zeiger (2015) Plant Physiology and Development",
      "Manual Práctico de Fertilización Orgánica Foliar, Agroecología del Sur."
    ]
  },
  {
    id: "modelo-holandes-cea",
    title: "Sistemas de Cultivo de Alto Rendimiento en Invernaderos de Holanda",
    category: "Artículos",
    subcategory: "Ambiente Controlado & Fisiología",
    difficulty: "Alto",
    cultivo: "Tomates de Racimo y Horticultura Protegida",
    author: "Wageningen University & Research (WUR)",
    date: "5 de Julio de 2026",
    version: "v1.0",
    licencia: "Creative Commons BY-NC-SA 4.0",
    tags: ["Invernaderos", "Holanda", "LED", "CO2", "Fisiología", "CEA"],
    description: "Estudio exhaustivo del modelo holandés de cultivo. Analiza la optimización del espectro de luz artificial rojo/azul, el control térmico estabilizado a 27°C y la fertilización carbónica con CO2 para lograr cosechas de hasta 80 kg/m².",
    fullText: "=== INTRODUCCIÓN GENERAL AL MODELO HOLANDÉS ===\n\n" +
              "El modelo hortícola de los Países Bajos (estilo holandés) es reconocido mundialmente por lograr rendimientos insuperables, como cosechas estables de 80 a 90 kg por metro cuadrado de tomate. Este éxito no se debe meramente al uso de tecnología aislada, sino a la integración sinérgica de factores climáticos y fisiológicos que maximizan la Eficiencia en el Uso de la Radiación y Nutrientes.\n\n" +
              "La industria holandesa opera bajo la regla empírica de que, bajo condiciones óptimas, un 1% más de luz equivale directamente a un 1% más de rendimiento potencial. Al controlar artificialmente el microclima, el clima exterior se vuelve irrelevante.\n\n" +
              "=== 1. LA FISIOLOGÍA DE LA LUZ Y LAS RECETAS LED DINÁMICAS ===\n\n" +
              "La eficiencia fotosintética depende drásticamente de la calidad espectral de la luz. El rendimiento cuántico de la fijación de CO₂ presenta un máximo en la región roja y un hombro intermedio en la región azul. Esto se explica por la absorción coordinada de las clorofilas a, b y carotenoides.\n\n" +
              "• Sinergia Lumínica (85-90% Rojo / 10-15% Azul): El espectro rojo (660 nm) es el motor fotosintético más eficiente por vatio invertido. Sin embargo, la luz azul (450 nm) es indispensable para regular la apertura estomática, controlar el grosor de las hojas y evitar el estiramiento anormal de los tallos (síndrome de evitación de la sombra).\n\n" +
              "• Iluminación Intercalada (Intra-canopy Lighting): Dado que las tomateras crecen de 4 a 5 metros verticalmente, se colocan líneas de luces LED entre el follaje (interiluminación). Esto evita que el dosel superior sombree las hojas bajas, activando la fotosíntesis en todo el volumen de la planta e incrementando el rendimiento global en un 25%.\n\n" +
              "• Transiciones de Estado y STN7 Quinasa: El aparato fotosintético regula la energía entre el Fotosistema II (PSII) y el Fotosistema I (PSI) mediante complejos LHCII móviles. Bajo desequilibrios de luz, el pool de plastoquinona (PQ) actúa como sensor. Si el PSII se sobreexcita, PQ se reduce y activa la quinasa STN7, fosforilando proteínas para desplazar LHCII hacia el PSI (Estado 2). Al restablecerse el equilibrio, las fosfatasas TAP38 y PPH1 desfosforilan el complejo, regresando al Estado 1. Estas transiciones aumentan el rendimiento cuántico de fijación de CO₂ entre un 10% y 13% en minutos.\n\n" +
              "=== 2. CONTROL TÉRMICO ESTABILIZADO A 27°C Y GESTIÓN DEL VPD ===\n\n" +
              "Mantener una temperatura constante de 27°C acelera de forma drástica la velocidad de desarrollo celular y maduración del fruto. Sin embargo, los sistemas LED no emiten radiación infrarroja (calor), por lo que la temperatura foliar óptima se gestiona con tuberías hidrónicas y deshumidificación activa.\n\n" +
              "• El papel de la Rubisco: La enzima Rubisco funciona como carboxilasa (fijando CO₂) y oxigenasa (desatando la fotorrespiración). A mayores temperaturas, la solubilidad del CO₂ disminuye más rápido que la del O₂, aumentando la fotorrespiración y el consumo energético (lo que puede reducir el rendimiento cuántico neto hasta un 29% a 35°C).\n\n" +
              "• El Desafío del Déficit de Presión de Vapor (VPD): En un invernadero cerrado a 27°C, la planta transpira masivamente. Si la humedad relativa supera el 85%, la transpiración se detiene, bloqueando el transporte de Calcio y provocando pudrición apical (Blossom End Rot). Se instalan deshumidificadores industriales (como DryGair) que condensan el exceso de vapor, devolviendo aire cálido seco y recuperando agua destilada purificada.\n\n" +
              "=== 3. FERTILIZACIÓN CARBÓNICA CON CO₂ EN LA BASE DEL DOSEL ===\n\n" +
              "A 27°C y alta iluminación LED, el CO₂ se agota en minutos. Para evitar que sea el factor limitante, se inyecta de forma constante hasta alcanzar niveles de 800 ppm a 1000 ppm.\n\n" +
              "• Inyección Localizada: El gas de CO₂ se distribuye localmente por tuberías plásticas microperforadas tendidas justo en la base de cada línea de cultivo. Al ascender de forma homogénea, cruza el área foliar donde los estomas lo absorben directamente antes de que escape.\n\n" +
              "• Origen de Suministro: El CO₂ proviene de la purificación de los gases de combustión de plantas de cogeneración eléctrica (motores CHP) o tanques criogénicos. Se detiene de inmediato si la ventilación cenital se abre más de un 30%.\n\n" +
              "=== 4. PLAN OPERATIVO DE REPLICACIÓN DE ALTO RENDIMIENTO ===\n\n" +
              "Para replicar estas cosechas récord en proyectos locales, es preciso estructurar la producción en tres niveles:\n\n" +
              "1. CANALETAS SUSPENDIDAS Y SUSTRATO INERTE: Cultivar sobre tablas de lana de roca (Rockwool) o fibra de coco en canaletas elevadas a 1 metro de altura. Esto previene patógenos del suelo, controla la temperatura de la raíz y optimiza la recolección de drenaje.\n\n" +
              "2. LAZO CERRADO Y RECIRCULACIÓN: Aplicar fertirriego por goteo automatizado. El drenaje del 30% sobrante es recolectado, desinfectado con ozono o luz UV, reequilibrado nutricionalmente y reinyectado, eliminando pérdidas de fertilizantes.\n\n" +
              "3. DENSIDAD DE TALLOS DINÁMICA: Iniciar con 2.5 tallos/m² y aumentarlo hasta 4.5 o 5.5 tallos/m² permitiendo brotes secundarios a medida que se activa el soporte de iluminación LED invernal, multiplicando la productividad por superficie.",
    downloads: 1250,
    relatedCourses: ["suelo-vivo", "biofertilizantes"],
    sources: [
      "Wageningen University & Research (WUR) - Greenhouse Horticulture Department",
      "Autonomous Greenhouse Challenge - Reports on LED and CO2 integration (2024-2026)",
      "Signify Philips Lighting - Light Recipes for Greenhouse Vegetables"
    ]
  }
];

export const COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: "post-1",
    title: "¿Cómo controlar la mosca blanca de forma 100% ecológica en tomates?",
    category: "Plagas",
    author: "Don Ramiro - Agricultor Familiar (Boyacá)",
    content: "Saludos compañeros de Agricultura Antigua. Tengo un pequeño invernadero de tomates cherry y en la última semana he tenido una invasión fuerte de mosca blanca en el envés de las hojas inferiores. He probado con té de ajo y ají, pero parece que vuelven al par de días. ¿Alguno me puede recomendar un protocolo más fuerte que no sea químico? ¡Muchas gracias!",
    date: "Ayer a las 18:23",
    likes: 24,
    replies: [
      {
        id: "rep-1",
        author: "Inge Alejandro Salazar",
        content: "Estimado Ramiro, el té de ajo y ají es un buen repelente, pero ante una plaga establecida necesitas una acción de contacto físico fuerte. Te sugiero aplicar jabón potásico al 1% combinado con aceite de neem. Esto disuelve la capa cerosa protectora de la mosca blanca y de sus huevos, ahogándolas de inmediato. Aplícalo estrictamente al atardecer para evitar quemaduras solares.",
        date: "Hace 15 horas"
      },
      {
        id: "rep-2",
        author: "Mariana G. - Huertera Urbana",
        content: "A mí me ha funcionado de maravilla colocar trampas cromáticas amarillas. Compras un plástico amarillo rígido, lo untas con aceite de cocina usado o vaselina, y lo cuelgas cerca de las plantas. Las moscas blancas son fuertemente atraídas por el color amarillo brillante, vuelan hacia él y se quedan pegadas. ¡Es súper barato y efectivo para bajar la población rápido!",
        date: "Hace 10 horas"
      }
    ]
  },
  {
    id: "post-2",
    title: "Éxito con Bokashi en Suelos Arcillosos Compactados",
    category: "Casos de Éxito",
    author: "Finca El Renacer (Ecuador)",
    content: "Queremos compartir nuestra alegría. Nuestro suelo es extremadamente arcilloso, casi greda de ladrillo, y con la sequía se agrietaba y compactaba como piedra. Empezamos a aplicar 500g de abono Bokashi por metro cuadrado directamente sobre las camas de cultivo, cubriéndolas con 10cm de paja de trigo. En solo 6 meses, el suelo ha cambiado de color, está suave, retiene la humedad y las raíces de nuestras hortalizas se desarrollan el doble de rápido. ¡La microbiología funciona de verdad!",
    date: "Hace 3 días",
    likes: 42,
    replies: [
      {
        id: "rep-3",
        author: "MSc. Kenji Takahashi",
        content: "¡Excelente reporte! El Bokashi aporta ácidos húmicos y fúlvicos cargados negativamente que flocularán las arcillas compactadas, abriendo canales microscópicos para el agua y el aire. El mulching (paja) evita que el sol incida de manera directa evaporando la humedad y matando las micorrizas. ¡Sigan adelante!",
        date: "Hace 2 días"
      }
    ]
  }
];

// ============================================================
// AGRICULTURA ANTIGUA, PARA ¡HOY! - BASE DE DATOS COMPLETA
// ============================================================

// ------------------------------------------------------------
// 1. PILARES (con temas completos)
// ------------------------------------------------------------
export const PILARES: Pilar[] = [
  {
    id: 'suelo-vivo',
    icono: '🌍',
    titulo: 'Suelo Vivo',
    subtitulo: 'El Ecosistema Invisible',
    descripcion: 'El suelo no es un sustrato inerte, sino un elemento vivo. Microbiología de consorcio, descompactación mecánica y biológica, y energía a través del ORP (Potencial Óxido-Reducción).',
    temas: [
      'Microbiología de Consorcio (600 microorganismos del bosque)',
      'Descompactación Mecánica y Biológica',
      'Energía and ORP (Potencial Óxido-Reducción)',
      'Salud Física del Suelo (porosidad, oxígeno)',
      'Infiltración y Retención de Agua (1% MO = 144,000 L/ha)',
      'Ciclos Físico-Químico-Biológicos',
      'IASS - Índice de Sustentabilidad del Suelo'
    ],
    color: '#2d5a27',
    bgColor: '#e8f0e6'
  },
  {
    id: 'nutricion-vegetal',
    icono: '☀️',
    titulo: 'Nutrición Vegetal Integral',
    subtitulo: 'Cosechando el Sol',
    descripcion: 'La agricultura como proceso de captación de energía lumínica. La Regla del 95/5, nutrición lumínica, carbónica, de hidrógeno y el Silicio como elemento maestro.',
    temas: [
      'La Regla del 95/5 (C-H-O: 95% de la planta es gratis)',
      'Nutrición Lumínica (Cuántica) - Captura de fotones',
      'Nutrición Carbónica (CO₂) - El fertilizante más importante',
      'Nutrición de Hidrógeno (Agua) - El vehículo de energía',
      'Bioquímica del Silicio - El "Padre del Silicio"',
      'Biosilicificación - Formación de fitolitos y tricomas',
      'Tricomas y Fitolitos - Defensa y captura de luz',
      'Fertilizantes Híbridos de Lenta Liberación'
    ],
    color: '#C49B6C',
    bgColor: '#f5eee6'
  },
  {
    id: 'bioinsumos',
    icono: '🧪',
    titulo: 'Bioinsumos',
    subtitulo: 'La Biofábrica Utopía',
    descripcion: 'Instrucciones prácticas para montar una biofábrica de alta concentración en solo 10 m². Procesos aeróbicos, minerales quelatados y ácidos orgánicos.',
    temas: [
      'Estación 1: Microorganismos de Montaña (Sólidos)',
      'Estación 2: Microorganismos Benéficos (Líquidos)',
      'Estación 3: Estiércol Falso (Sólido Nutritivo)',
      'Estación 4: Biol Potenciado',
      'Estación 5: Multimineral Quelado (60 minerales)',
      'Estación 6: Ácidos Húmicos y Fúlvicos',
      'Estación 7: Fungicidas Orgánicos (Sulfocálcico, Bordelés)',
      'Estación 8: Insecticidas Orgánicos (Jabón Potásico, Neem)',
      'Estación 9: Programa Integrado de Control'
    ],
    color: '#4a7a43',
    bgColor: '#e6efe5'
  },
  {
    id: 'agricultura-tradicional',
    icono: '🌾',
    titulo: 'Agricultura Tradicional',
    subtitulo: 'Sabiduría Ancestral',
    descripcion: 'Rescate de modelos ignorados por la Revolución Verde: Milpa Maya, Terrazas Incas, Chinampas, Ingeniería Jemer, Subak, Policultura China, e Irrigación en la India Antigua y Babilonia.',
    temas: [
      'Sistema Milpa Maya - 9 mazorcas por planta',
      'Terrazas Incas y Diseño Hidrológico',
      'Chinampas Aztecas y Agricultura de Humedales',
      'Control de Arvenses - La maleza como aliada',
      'Ingeniería Hidráulica Jemer (Camboya)',
      'Sistema Subak de Bali (Indonesia)',
      'Policultura del Arrozal Inundado (China)',
      'Tecnologías e Innovación China (Ao Tian)',
      'Sistemas del Monzón y Tanques (India Antigua)',
      'Control de Ríos y Desalinización (Babilonia)',
      'Rescate de la Sabiduría Ancestral',
      'Descolonización Científica y Tecnológica',
      'El mito del maíz que se multiplicaba'
    ],
    color: '#8B6F47',
    bgColor: '#f0ebe0'
  },
  {
    id: 'ciencia-moderna',
    icono: '🔬',
    titulo: 'Ciencia Moderna',
    subtitulo: 'Tecnología de Frontera',
    descripcion: 'Herramientas para dejar de cultivar a ciegas. Metagenómica, microscopía electrónica, fertilización híbrida y dispositivos analíticos móviles.',
    temas: [
      'Metagenómica - ADN del suelo y microbiomas',
      'Microscopía Electrónica de Barrido (SEM)',
      'ORP - Medición de la Energía del Suelo',
      'Dispositivos Analíticos Móviles (pH, CE, ORP)',
      'Arado Yomex - Descompactación a 60-80 cm',
      'Innovaciones Tecnológicas (Apps, drones, sensores)',
      'SRI - Sistema de Intensificación del Arroz'
    ],
    color: '#1A3A5C',
    bgColor: '#e4ecf2'
  }
];

// ------------------------------------------------------------
// 2. MITOS (con realidad, evidencia y acción completos)
// ------------------------------------------------------------
export const MITOS: Mito[] = [
  {
    id: 'mito-1',
    titulo: 'Las plantas comen tierra',
    mito: '"Las plantas se alimentan de la tierra. Si quieres que una planta crezca grande y fuerte, necesitas darle más tierra o más fertilizante."',
    realidad: 'La planta NO come tierra. La planta se construye a sí misma a partir del AIRE y del AGUA.',
    evidencia: 'El experimento de Van Helmont (1624): un sauce creció de 2.28 kg a 85 kg en 5 años, mientras que la tierra solo perdió 56 gramos.',
    accion: 'El 95% de tu cosecha es GRATIS. Enfócate en optimizar la fotosíntesis, el CO₂ y el agua.',
    icono: '🌱',
    color: '#2d5a27'
  },
  {
    id: 'mito-2',
    titulo: 'Más fertilizante = más producción',
    mito: '"Si quieres más producción, aplica más fertilizante. Cuanto más NPK, más cosecha."',
    realidad: 'La producción NO es directamente proporcional a la cantidad de fertilizante. El 80% del fertilizante se pierde.',
    evidencia: 'La Ley del Mínimo (Liebig): el nutriente menos disponible es el que limita la producción.',
    accion: 'Identifica el factor más limitante (temperatura, agua, compactación, luz) y optimízalo.',
    icono: '💰',
    color: '#C49B6C'
  },
  {
    id: 'mito-3',
    titulo: 'El suelo es solo un soporte',
    mito: '"El suelo es solo el soporte físico donde la planta echa raíces. Es como una maceta gigante."',
    realidad: 'El suelo NO es un soporte inerte. El suelo es un ORGANISMO VIVO con millones de microorganismos.',
    evidencia: 'En 1 gramo de suelo fértil hay 100-500 millones de bacterias, 1-10 millones de hongos.',
    accion: 'Gestiona el suelo como el patrimonio más valioso que tienes.',
    icono: '🌍',
    color: '#4a7a43'
  },
  {
    id: 'mito-4',
    titulo: 'La M.O. solo sirve para nutrientes',
    mito: '"La materia orgánica es solo una fuente de nutrientes. Si pones suficiente fertilizante, no necesitas materia orgánica."',
    realidad: 'La materia orgánica es el MOTOR del suelo vivo: retiene agua, regula temperatura, alimenta microorganismos.',
    evidencia: '1% de materia orgánica = 144,000 litros de agua por hectárea.',
    accion: 'Reincorporpora todos los residuos de cosecha y mantén cobertura vegetal permanente.',
    icono: '💧',
    color: '#8B6F47'
  },
  {
    id: 'mito-5',
    titulo: 'La agricultura orgánica produce menos',
    mito: '"La agricultura orgánica produce menos que la agricultura convencional."',
    realidad: 'La agricultura orgánica de última generación produce MÁS con MENOS insumos y MENOS costos.',
    evidencia: 'UABCS: 5 espigas por planta; Sumant Kumar: 22.4 t/ha de arroz (récord mundial).',
    accion: 'Aplica el protocolo de 100 días y la ciencia de frontera.',
    icono: '📈',
    color: '#1A3A5C'
  },
  {
    id: 'mito-6',
    titulo: 'El pH es el indicador más importante',
    mito: '"El pH es el indicador más importante del suelo. Si el pH no está en el rango correcto, los nutrientes no están disponibles."',
    realidad: 'El ORP (Potencial Óxido-Reducción) mide la ENERGÍA del suelo y es más importante que el pH.',
    evidencia: 'Un suelo con pH perfecto pero oxidado consume la energía de la planta.',
    accion: 'Mide el ORP de tu suelo y aplícale bioles con carga energética negativa.',
    icono: '⚡',
    color: '#D4A853'
  },
  {
    id: 'mito-7',
    titulo: 'Las cabañuelas predicen el clima',
    mito: '"Los primeros 12 días de enero predicen el clima de todo el año."',
    realidad: 'Las cabañuelas no tienen sustento científico. La probabilidad de acierto es solo del 30%.',
    evidencia: 'Los meteorólogos confirman que la correlación es por casualidad, no por causalidad.',
    accion: 'La mejor predicción del clima es un suelo que retiene agua. 1% de MO = 144,000 L/ha.',
    icono: '🌤️',
    color: '#6B8C6B'
  },
  {
    id: 'mito-8',
    titulo: 'La milpa de dos puntas es sagrada',
    mito: '"La milpa que tiene dos puntas es una figura sagrada. Se le piden mazorcas para todo el año."',
    realidad: 'Una planta con dos espigas es el resultado de buena nutrición y condiciones favorables.',
    evidencia: 'El fósforo, zinc, silicio y micronutrientes determinan el número de espigas.',
    accion: 'Aprende a nutrir el suelo para que todas tus plantas sean productivas.',
    icono: '🌽',
    color: '#C49B6C'
  },
  {
    id: 'mito-9',
    titulo: 'Las gotas de rocío queman las plantas',
    mito: '"Las gotas de rocío actúan como lentes, quemando las plantas cuando el sol las atraviesa."',
    realidad: 'Las gotas de agua NO queman las hojas. El problema son los hongos.',
    evidencia: 'El efecto lupa no concentra suficiente energía; las manchas son síntomas de enfermedades fúngicas.',
    accion: 'Aplica silicio para fortalecer la planta y evitar que los hongos penetren la hoja.',
    icono: '💦',
    color: '#4A7A8C'
  }
];

// ------------------------------------------------------------
// 3. CASOS DE ÉXITO
// ------------------------------------------------------------
export const CASOS_EXITO: CasoExito[] = [
  {
    id: 'uabcs',
    titulo: 'UABCS: 5 Espigas por Planta',
    descripcion: 'La Universidad Autónoma de Baja California Sur aplicó el modelo Utopía al cultivo de maíz con resultados impresionantes.',
    icono: '🌽',
    cultivo: 'Maíz',
    ubicacion: 'Baja California Sur, México',
    resultados: [
      '5 espigas por planta (vs. 1-2 convencional)',
      '20 hileras por espiga (vs. 12-14 convencional)',
      '41 granos por hilera (vs. 30-35 convencional)',
      '8.7-11 toneladas/ha (vs. 4-6 convencional)'
    ]
  },
  {
    id: 'sumant-kumar',
    titulo: 'Sumant Kumar: Récord Mundial',
    descripcion: 'En Bihar, India, logró el récord mundial usando SRI (Sistema de Intensificación del Arroz).',
    icono: '🌾',
    cultivo: 'Arroz',
    ubicacion: 'Bihar, India',
    resultados: [
      '22.4 toneladas/ha (vs. 4-8 convencional)',
      '5 kg de semilla/ha (vs. 35-40 kg convencional)',
      '50% menos agua (vs. inundación continua)',
      '34.4 macollos/planta (vs. 19.4 convencional)'
    ]
  },
  {
    id: 'valle-cauca',
    titulo: 'Valle del Cauca: 50% Menos Costos',
    descripcion: 'Agricultores del Valle del Cauca redujeron sus costos de producción entre un 40-50% con el modelo Utopía.',
    icono: '🇨🇴',
    cultivo: 'Variados',
    ubicacion: 'Valle del Cauca, Colombia',
    resultados: [
      '40-50% menos costos de producción',
      'Suelo regenerado',
      'Mayor resiliencia a plagas',
      'Cosechas más abundantes'
    ]
  }
];

// ------------------------------------------------------------
// 4. NÚMEROS CLAVE
// ------------------------------------------------------------
export const NUMEROS_CLAVE: NumeroClave[] = [
  { valor: '95%', label: 'de la planta es C-H-O (gratis del aire y el agua)' },
  { valor: '144,000', label: 'litros de agua retiene 1% de MO por hectárea' },
  { valor: '12°C', label: 'reduce la temperatura foliar el silicio' },
  { valor: '5', label: 'espigas por planta con el protocolo Utopía' },
  { valor: '22.4', label: 'toneladas de arroz por hectárea (récord mundial)' },
  { valor: '80%', label: 'del fertilizante convencional se pierde' },
  { valor: '40-50%', label: 'reducción de costos con el modelo Utopía' },
  { valor: '100', label: 'días antes de la siembra comienza el protocolo' }
];

// ------------------------------------------------------------
// 5. RECETAS
// ------------------------------------------------------------
export const RECETAS: Receta[] = [
  {
    id: 'biol-2',
    titulo: 'Microorganismos Benéficos (Estación 2)',
    descripcion: 'Cultivo líquido de microorganismos para aplicaciones al suelo y foliar.',
    ingredientes: ['5 kg de MM sólidos', '190 L de agua (sin cloro)', '4 kg de azúcar o melaza'],
    pasos: [
      'Llena el tambor con 190 L de agua',
      'Agrega 4 kg de azúcar y agita',
      'Cuelga el saco con 5 kg de MM sólidos',
      'Agita 10 min y tapa con tela',
      'Agita mañana y tarde por 10 min durante 8 días',
      'Día 9: LISTO PARA USAR'
    ],
    tiempo: '8 días',
    categoria: 'Bioinsumos',
    icono: '🧫'
  },
  {
    id: 'caldo-sulfocalcico',
    titulo: 'Caldo Sulfocálcico',
    descripcion: 'Fungicida, acaricida e insecticida orgánico. Controla más de 50 enfermedades fúngicas.',
    ingredientes: ['100 L de agua', '20 kg de azufre en polvo', '10 kg de cal'],
    pasos: [
      'Mezcla azufre y cal en seco',
      'Hierve el agua',
      'Añade la mezcla lentamente, agitando',
      'Cocina hasta color rojo vinotinto (20-30 min)',
      'Deja reposar y enfriar',
      'Guarda en recipientes opacos'
    ],
    tiempo: '1 hora',
    categoria: 'Caldos Minerales',
    icono: '🧪'
  },
  {
    id: 'empanizado-semillas',
    titulo: 'Empanizado de Semillas',
    descripcion: 'Tratamiento biológico y mineral para germinación uniforme y vigor inicial.',
    ingredientes: ['Estación 6', 'Estación 5', 'Estación 2', 'Melaza o azúcar', 'Roca fosfórica fina'],
    pasos: [
      'Mezcla partes iguales de Estaciones 6, 5 y 2',
      'Agrega melaza o azúcar',
      'Remoja las semillas',
      'Espolvorea con roca fosfórica',
      'Seca a la sombra por 24 h',
      '¡Siembra inmediatamente!'
    ],
    tiempo: '24 horas',
    categoria: 'Tratamiento de Semillas',
    icono: '🌱'
  }
];

// ------------------------------------------------------------
// 6. GLOSARIO TÉCNICO
// ------------------------------------------------------------
export const GLOSARIO: GlosarioItem[] = [
  { termino: 'ORP', definicion: 'Potencial Óxido-Reducción. Mide la carga de electrones (energía) en el suelo. Un suelo sano debe estar reducido (-100 a -300 mV).' },
  { termino: 'IASS', definicion: 'Índice Agrícola de Sustentabilidad del Suelo. Cuantifica el patrimonio suelo. Un valor de 30-40% es óptimo para productividad sustentable.' },
  { termino: 'MPASi', definicion: 'Minerales Primarios Amorfos ricos en Silicio. Componen la fracción cultivable del suelo (~4000 ton/ha).' },
  { termino: 'Biosilicificación', definicion: 'Proceso biológico de conversión de H₄SiO₄ soluble en SiO₂ amorfo (fitolitos) en la planta.' },
  { termino: 'Quelatación', definicion: 'Proceso químico donde un agente orgánico "encapsula" un ión mineral protegiéndolo de fijación en el suelo.' },
  { termino: 'Glomalina', definicion: 'Glicoproteína producida por hongos micorrícicos. Actúa como "pegamento" biológico estabilizando agregados del suelo.' },
  { termino: 'rH', definicion: 'Coeficiente que integra pH y ORP. rH = ((ORP + 200) / 30) + 2 × pH. Un rH bajo indica estado reducido (rico en energía).' },
  { termino: 'CICE', definicion: 'Capacidad de Intercambio Catiónico. Capacidad del suelo para retener e intercambiar cationes (Ca²⁺, Mg²⁺, K⁺).' }
];

// ------------------------------------------------------------
// 7. SUBTEMAS - Información detallada de cada tema
// ------------------------------------------------------------
export const SUBTEMAS: SubtemasMap = {
  // ============================================================
  // SUELO VIVO - TEMAS COMPLETOS
  // ============================================================
  'Microbiología de Consorcio (600 microorganismos del bosque)': {
    descripcion: 'Los microorganismos del bosque trabajan en equipo para fabricar fertilizante gratuito. No se usan cepas aisladas, sino consorcios completos que imitan los ecosistemas naturales.',
    subtemas: [
      'Bacterias (Bacillus, Pseudomonas) - Descomponen materia orgánica y liberan nutrientes',
      'Hongos (Micorrizas, Trichoderma) - Mejoran absorción de nutrientes y protegen raíces',
      'Actinomicetos - Producen antibióticos naturales que controlan patógenos',
      'Protozoos - Regulan poblaciones bacterianas y liberan nutrientes',
      'Nematodos benéficos - Controlan plagas del suelo y mejoran la estructura',
      'Consorcio completo - 600 microorganismos trabajando en equipo'
    ],
    icono: '🦠'
  },
  'Descompactación Mecánica y Biológica': {
    descripcion: 'Uso de implementos como el arado Yomex para romper el piso de arado a 60-80 cm e inyectar vida para que la raíz respire y se desarrolle profundamente.',
    subtemas: [
      'Arado Yomex - Rompe la compactación profunda sin invertir el perfil del suelo',
      'Inyección de microorganismos - Se introducen directamente en el perfil del suelo',
      'Raíces profundas - Acceso a nutrientes y agua en capas profundas',
      'Mejora de la porosidad - Aumenta el espacio para el intercambio de gases',
      'Eliminación del piso de arado - Desaparece la capa compactada que limita el crecimiento',
      'Beneficios biológicos - Los microorganismos mantienen la descompactación'
    ],
    icono: '🚜'
  },
  'Energía y ORP (Potencial Óxido-Reducción)': {
    descripcion: 'Medir el potencial de óxido-reducción; un suelo reducido (energía negativa) protege a la planta de plagas y enfermedades.',
    subtemas: [
      'ORP - Mide la carga de electrones (energía) disponible en el suelo',
      'Suelo reducido (-100 a -300 mV) - Rico en energía y vida microbiana',
      'Suelo oxidado (+200 a +400 mV) - Consume energía de la planta para sobrevivir',
      'Cómo medir ORP - Dispositivos portátiles para monitoreo en campo',
      'Relación ORP vs. resistencia - Suelos reducidos protegen contra plagas',
      'rH - Coeficiente que integra pH and ORP para una visión completa'
    ],
    icono: '⚡'
  },
  'Energía and ORP (Potencial Óxido-Reducción)': {
    descripcion: 'Medir el potencial de óxido-reducción; un suelo reducido (energía negativa) protege a la planta de plagas y enfermedades.',
    subtemas: [
      'ORP - Mide la carga de electrones (energía) disponible en el suelo',
      'Suelo reducido (-100 a -300 mV) - Rico en energía y vida microbiana',
      'Suelo oxidado (+200 a +400 mV) - Consume energía de la planta para sobrevivir',
      'Cómo medir ORP - Dispositivos portátiles para monitoreo en campo',
      'Relación ORP vs. resistencia - Suelos reducidos protegen contra plagas',
      'rH - Coeficiente que integra pH and ORP para una visión completa'
    ],
    icono: '⚡'
  },
  'Salud Física del Suelo (porosidad, oxígeno)': {
    descripcion: 'La estructura física del suelo determina la capacidad de las raíces para crecer, respirar y absorber nutrientes.',
    subtemas: [
      'Porosidad - Espacios entre partículas que permiten el movimiento de agua y aire',
      'Oxígeno - Esencial para la respiración de raíces y microorganismos aeróbicos',
      'Agregados estables - Estructura que resiste la erosión y mantiene la fertilidad',
      'Compactación - Principal limitante del crecimiento radicular',
      'Glomalina - Glicoproteína que actúa como "pegamento" biológico',
      'Buenas prácticas - Rotación de cultivos, cobertura vegetal, mínimo laboreo'
    ],
    icono: '🫧'
  },
  'Infiltración y Retención de Agua (1% MO = 144,000 L/ha)': {
    descripcion: 'La materia orgánica actúa como una esponja gigante en el suelo, reteniendo hasta 144,000 litros de agua por hectárea por cada 1% de materia orgánica.',
    subtemas: [
      'Materia orgánica - La "esponja" natural que absorbe y retiene agua',
      'Infiltración - Capacidad del suelo para absorber el agua de lluvia y riego',
      'Retención - Almacenamiento de agua disponible para las plantas',
      '1% MO = 144,000 L/ha - Dato clave para entender su importancia',
      'Refrigerante del suelo - Mantiene la fotosíntesis activa a 27°C',
      'Resiliencia a sequías - Suelos con alta MO resisten mejor periodos secos'
    ],
    icono: '💧'
  },
  'Ciclos Físico-Químico-Biológicos': {
    descripcion: 'Interacciones entre factores físicos, químicos y biológicos que mantienen el suelo vivo, productivo y en equilibrio.',
    subtemas: [
      'Ciclo del Carbono - Materia orgánica → CO₂ atmosférico → Fotosíntesis → Planta',
      'Ciclo del Nitrógeno - Fijación, nitrificación, asimilación, desnitrificación',
      'Ciclo del Fósforo - Mineralización, solubilización, absorción por raíces',
      'Interacción raíz-microorganismos - La rizosfera como ecosistema activo',
      'Balance físico-químico-biológico - El ecosistema completo del suelo',
      'Indicadores de salud - Cómo evaluar el equilibrio del suelo'
    ],
    icono: '🔄'
  },
  'IASS - Índice de Sustentabilidad del Suelo': {
    descripcion: 'Cuantifica el patrimonio suelo como un todo. Un valor de 30-40% es óptimo para una productividad sustentable a largo plazo.',
    subtemas: [
      '¿Qué es el IASS? - Indicador integral de salud y sustentabilidad del suelo',
      'Componentes del IASS - Físicos, químicos y biológicos del suelo',
      'Valores óptimos - 30-40% para producción sustentable y rentable',
      'Cómo medir el IASS - Métodos prácticos aplicables en campo',
      'Mejorar el IASS - Estrategias de manejo y conservación',
      'IASS como herramienta - Toma de decisiones para agricultores'
    ],
    icono: '📊'
  },
  'La Regla del 95/5 (C-H-O: 95% de la planta es gratis)': {
    descripcion: 'El 95% de la planta es Carbono, Oxígeno e Hidrógeno, elementos que se obtienen gratis del aire (CO₂) y el agua (H₂O).',
    subtemas: [
      'Carbono (C) - 45% de la planta, proviene del CO₂ del aire',
      'Oxígeno (O) - 45% de la planta, del agua y del aire',
      'Hidrógeno (H) - 5% de la planta, del agua',
      'Solo 5% de la planta - Viene del suelo (minerales y nutrientes)',
      'Optimizar fotosíntesis - La clave para aumentar producción',
      'Consecuencias - El 95% de tu cosecha es GRATIS'
    ],
    icono: '💨'
  },
  'Sistema Milpa Maya - 9 mazorcas por planta': {
    descripcion: 'Sistema de policultivo precolombino basado en la sinergia de las "Tres Hermanas" (maíz, frijol y calabaza) que maximiza el rendimiento por superficie.',
    subtemas: [
      'El Maíz como Tutor: Provee estructura vertical física y soporte mecánico para que el frijol trepe hacia la luz solar.',
      'El Frijol como Fijador: Simbiosis con bacterias Rhizobium para fijar nitrógeno atmosférico gratuito directo a las raíces del consorcio.',
      'La Calabaza como Cobertura: Hojas gigantescas que cubren el suelo técnico reteniendo humedad y evitando el nacimiento de arvenses invasoras.',
      'Nutrición Mineral de Altura: El uso de harinas de rocas, Silicio y cenizas volcánicas rústicas permite activar hasta 9 mazorcas por planta.',
      'Soberanía Alimentaria Completa: Aporte equilibrado de carbohidratos, proteínas y lípidos saludables en un mismo espacio de cultivo.'
    ],
    icono: '🌽'
  },
  'Terrazas Incas y Diseño Hidrológico': {
    descripcion: 'Sistemas andinos de laderas escalonadas y canales de piedra que evitan la erosión, retienen agua y amortiguan heladas mediante inercia térmica.',
    subtemas: [
      'Drenaje Multicapa de Precisión: Base profunda de piedras grandes, grava media, arena lavada y tierra vegetal con alto humus para filtrar excesos.',
      'Inercia Térmica de Piedra: Muros perimetrales que absorben calor solar diurno y lo irradian de noche, previniendo la congelación foliar.',
      'Canales Hidráulicos Gravitacionales: Conducción de agua desde lagunas de altura (cochas) con gradientes de fricción calculados para evitar erosión.',
      'Moray (Laboratorio Agrícola): Terrazas circulares concéntricas que generan hasta 15°C de diferencia térmica para aclimatación de semillas de selva.',
      'Conservación del Suelo Técnico: Freno absoluto de escorrentías torrenciales en laderas escarpadas, acumulando capas fértiles por siglos.'
    ],
    icono: '🏔️'
  },
  'Chinampas Aztecas y Agricultura de Humedales': {
    descripcion: 'El sistema mesoamericano de islas artificiales flotantes en lagos someros, considerado uno de los métodos más intensivos y sostenibles creados.',
    subtemas: [
      'Islas de Sauce (Huejotes): Entramados de ramas de sauces nativos que consolidan las paredes perimetrales de la chinampa con raíces profundas.',
      'Riego de Capilaridad Pasiva: Absorción constante de agua por porosidad de las capas de suelo técnico sin necesidad de esfuerzo mecánico de riego.',
      'Fertilidad con Lodo Lacustre: Dragado periódico de los sedimentos ricos en materia orgánica y fósforo del fondo del canal para cubrir camas de siembra.',
      'Semilleros de Lodo (Chapines): Cuadrículas de lodo del lago cortadas en bloques de alta germinación para trasplantes con cero estrés radicular.',
      'Sistemas de Policultivo Lacustre: Producción coordinada de maíz, frijol, chile, calabaza y flores comestibles con hasta 5 cosechas anuales estables.'
    ],
    icono: '🛶'
  },
  'Control de Arvenses - La maleza como aliada': {
    descripcion: 'Uso de plantas silvestres como coberturas vivas, bombas de minerales insolubles y albergue de fauna benéfica del agroecosistema.',
    subtemas: [
      'Plantas Bomba de Nutrientes: Raíces profundas que extraen minerales bloqueados (fósforo, oligoelementos) y los depositan arriba al podarse.',
      'Conservación de Temperatura: Disminución de hasta 10°C en la superficie del suelo, manteniendo activa la microbiología en sequías.',
      'Soporte a Fauna Benéfica: Flores nativas de arvenses que alimentan avispas parasitoides y crisopas controladoras de insectos dañinos.',
      'Arvenses como Bioindicadores: Familias botánicas cuya germinación espontánea acusa compactación, asfixia radicular o exceso de nitratos.',
      'Manejo Selectivo sin Herbicidas: Segar superficialmente en lugar de desyerbar de raíz para mantener la red micorrícica intacta en el perfil.'
    ],
    icono: '🌿'
  },
  'Ingeniería Hidráulica Jemer (Camboya)': {
    descripcion: 'El colosal sistema de captación y regulación hídrica de Angkor que dominó los climas monzónicos bimodales del sudeste asiático.',
    subtemas: [
      'Megarreservorios Elevated (Barays): Lagos artificiales como el Baray Occidental (8 x 2.2 km) creados con diques perimetrales de tierra de 10m de altura.',
      'Alimentación Hidráulica: Canales que captaban caudales excedentes de ríos monzónicos (río Siem Reap) y los reconducían para almacenamiento masivo.',
      'Distribución Gravitacional: Apertura manual de compuertas de piedra que liberaban agua dulce constante por pura gravedad hacia la llanura agrícola.',
      'Arroz Flotante Monzónico: Variedad con estiramiento celular acelerado de hasta 5-6 metros para mantener sus espigas a flote en inundaciones.',
      'Seguridad Alimentaria Continua: Suministro hidráulico constante que garantizó hasta tres cosechas de arroz anuales, rompiendo la sequía extrema.'
    ],
    icono: '🏯'
  },
  'Sistema Subak de Bali (Indonesia)': {
    descripcion: 'Democracia hídrica y control natural de plagas en laderas volcánicas ricas en potasio, fósforo y magnesio.',
    subtemas: [
      'Terrazas de Retención Arcillosa: Diques hechos con arcilla mezclada con paja y piedra para retener capas de agua estática de 5 a 12 cm en laderas.',
      'Túneles y Acueductos de Piedra: Kilométricas galerías excavadas directamente en la roca de barrancos selváticos para guiar agua por gravedad.',
      'Templos del Agua (Pura): Red cooperativa jerárquica donde sacerdotes del agua y agricultores coordinan turnos democráticos de riego.',
      'Sincronización contra Plagas: Cosecha simultánea y barbecho seco coordinado en toda la región para romper la cadena alimenticia de roedores e insectos.',
      'Filosofía Tri Hita Karana: Enfoque integral que fusiona la fe espiritual, la armonía humana y el cuidado técnico del ecosistema hídrico.'
    ],
    icono: '🌋'
  },
  'Policultura del Arrozal Inundado (China)': {
    descripcion: 'Aprovechamiento biológico multi-nivel del humedal artificial del arrozal en el sur de China mediante simbiosis animal.',
    subtemas: [
      'Flujo de Desbordamiento Serpentino: Agua fría de manantiales superiores que fluye lentamente por compuertas de bambú para evitar la anoxia de raíces.',
      'Simbiosis Arroz-Pez (Carpas): Peces que nadan oxigenando el lodo, devoran larvas de plagas y malas hierbas, y fertilizan el agua con nitrógeno y fósforo.',
      'Asociación Arroz-Pato: Patos jóvenes que controlan caracoles y escarabajos invasores, y estimulan con sus patas el enraizamiento profundo.',
      'Tratados de Agricultura (Nong Shu): Manuales de estado oficiales precisos sobre preparación del suelo, diseño hidráulico y selección de semillas.',
      'Eficiencia de Espacio Humedal: Producción simultánea de granos limpios y proteína animal de excelente calidad en el mismo metro cuadrado.'
    ],
    icono: '🇨🇳'
  },
  'Tecnologías e Innovación China (Ao Tian)': {
    descripcion: 'Maquinaria de precisión tradicional y métodos térmicos y orgánicos avanzados de protección hortícola.',
    subtemas: [
      'Bomba de Cadena (Longgu Che): Paletas articuladas en canaletas inclinadas movidas por pedales para elevar agua masivamente a colinas.',
      'Arado de Hierro Curvo (Kuan): Vertedera curva de hierro fundido que voltea la tierra arcillosa húmeda con mínima fricción del animal de tiro.',
      'Norias Autónomas de Bambú: Ruedas gigantes que usan la fuerza del río para cargar agua en tubos de bambú e irrigar tierras altas sin energía humana.',
      'Cultivo en Fosas (Ao Tian): Pozos profundos enriquecidos con compost que frenan vientos helados de Mongolia y retienen calor solar invernal.',
      'Trampas de Luz e Inversión Lumínica: Antorchas con cuencos de agua y aceite que atraen y eliminan orugas y polillas nocturnas en arrozales.',
      'Hormigas Tejederas Protectoras: Primer control biológico citrus (Oecophylla smaragdina) para devorar plagas, uniendo árboles con puentes de bambú.'
    ],
    icono: '⚙️'
  },
  'Sistemas del Monzón y Tanques (India Antigua)': {
    descripcion: 'Gestión pluvial en Gujarat y Baluchistán frente al régimen monzónico del valle del Indo e insecticidas biológicos ancestrales.',
    subtemas: [
      'Tanques de Dholavira: Red de 16 colosales depósitos rectangulares de piedra caliza tallada para recolectar escorrentías de torrentes estacionales.',
      'Gabarbands de Baluchistán: Presas horizontales de piedra diseñadas para frenar escorrentías, retener limo aluvial y recargar mantos acuíferos.',
      'Rotación Estacional Rabi y Kharif: Cultivo de verano (Kharif: arroz, algodón, mijo) y secas con humedad residual (Rabi: trigo, cebada, leguminosas).',
      'Protección Térmica de Inundación: Inundación preventiva nocturna para aprovechar el calor latente del agua y frenar heladas secas de radiación.',
      'Aceite de Neem (Krishi-Parashara): Insecticida bioquímico de semillas de Neem que sabotea el sistema hormonal y metamorfosis de insectos plaga.'
    ],
    icono: '🇮🇳'
  },
  'Control de Ríos y Desalinización (Babilonia)': {
    descripcion: 'Control hidráulico del Tigris y Éufrates y mitigación de salinidad del suelo mediante bioquímica tradicional babilónica.',
    subtemas: [
      'Canales de Desviación Elevados: Canales de toma alta que llevaban agua por encima de los campos, permitiendo riego por gravedad.',
      'Esclusas Impermeables con Betún: Compuertas de ladrillo selladas con asfalto natural para regular excedentes fluviales hacia lagunas secas.',
      'Sustitución Osmótica de Cebada: Reemplazo sistemático del trigo sensible por cebada (Hordeum vulgare), planta altamente tolerante a sales.',
      'Lavado Químico y Drenajes Abiertos: Zanjas profundas paralelas de desagüe que recibían el agua cargada con sales superficiales disueltas.',
      'Barbecho de Maleza (Shuqal): Descanso del suelo alternado con arbustos de raíces profundas que bajaban el nivel freático para evitar salinización por capilaridad.',
      'Oasis en Tres Niveles: Palmeras datileras (barrera de calor), frutales intermedios (sombra parcial) y cereales/hortalizas inferiores protegidos.'
    ],
    icono: '🧱'
  },
  'Rescate de la Sabiduría Ancestral': {
    descripcion: 'Recuperación de los principios de diseño ecológico desarrollados durante milenios y su validación con herramientas científicas modernas.',
    subtemas: [
      'Sostenibilidad Milenaria: Sistemas que produjeron alimentos durante siglos sin agotar el recurso hídrico ni erosionar la fertilidad del suelo.',
      'Uso de Recursos Locales de la Finca: Reducción total de insumos químicos petroquímicos costosos utilizando preparados microbiológicos locales.',
      'Observación de Ciclos Biológicos: Planificación basada en patrones climáticos locales, fases de la luna y comportamiento de la microfauna.',
      'Conservación de Semillas Criollas: Selección activa y resguardo de germoplasma nativo altamente adaptado a climas cambiantes y rústicos.',
      'Gestión Comunitaria: Organización social colaborativa para administrar infraestructuras comunes (acequias, turnos de agua, bancos de semillas).'
    ],
    icono: '🏺'
  },
  'Descolonización Científica y Tecnológica': {
    descripcion: 'Ruptura del monopolio agroquímico de la Revolución Verde para validar la ciencia y eficiencia de las técnicas agrarias tradicionales.',
    subtemas: [
      'Superación del Paradigma NPK: Comprender que la vida de la planta depende del microbioma del suelo y la nutrición mineral completa y balanceada.',
      'Validación Biológica de Campo: Uso de microscopía y metagenómica para demostrar que las prácticas ancestrales activaban microbiomas sanos.',
      'Soberanía Productiva Completa: Empoderar al agricultor para que fabrique sus bioinsumos y rompa la cadena de dependencia comercial sintética.',
      'El Saber Campesino como Ciencia: Integrar la experimentación empírica y la observación acumulada con los marcos conceptuales modernos.',
      'Rendimiento Neto de Energía: Demostración de que la policultura tradicional supera en rendimiento calórico neto por hectárea a los monocultivos.'
    ],
    icono: '🛡️'
  },
  'El mito del maíz que se multiplicaba': {
    descripcion: 'La historia de la domesticación del teocintle y la creación del maíz, la mayor obra de biotecnología precolombina de América.',
    subtemas: [
      'Domesticación del Teocintle: Selección guiada durante miles de años para transformar una gramínea dura en una mazorca comestible gigante.',
      'Riqueza Varietal Adaptativa: Cientos de razas criollas con variabilidades genéticas adaptadas a climas áridos, selvas lluviosas y altiplanos.',
      'Nixtamalización Mesoamericana: Cocción de granos con cal mineral o ceniza de madera, proceso que libera niacina y previene enfermedades nutricionales.',
      'Simbiosis Biológica Humana: Co-evolución estricta entre la planta de maíz (incapaz de desgranarse sola para reproducirse) y el campesino.',
      'Almacenamiento Seguro (Trojes): Estructuras tradicionales de ventilación y control de humedad que preservaban los granos de gorgojos por años.'
    ],
    icono: '🌽'
  }
};

