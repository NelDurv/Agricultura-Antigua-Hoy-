/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum UserMembership {
  Visitor = "Visitante",
  Free = "Usuario Registrado",
  Premium = "Miembro Premium",
  Institutional = "Institución"
}

export interface Module {
  id: string;
  title: string;
  duration: string;
  type: "lecture" | "quiz" | "practical";
  content: string;
  quiz?: {
    question: string;
    options: string[];
    correctAnswer: number;
  };
}

export interface Course {
  id: string;
  title: string;
  description: string;
  extendedDescription?: string;
  level: "Principiante" | "Intermedio" | "Avanzado";
  category: string;
  duration: string;
  lessonsCount: number;
  image: string;
  rating: number;
  isPremium: boolean;
  author: string;
  modules: Module[];
}

export interface BibliotecaDoc {
  id: string;
  title: string;
  category: "Artículos" | "Manuales" | "Fichas Técnicas" | "Protocolos" | "Guías" | "Infografías";
  subcategory: string;
  difficulty: "Bajo" | "Medio" | "Alto";
  cultivo: string;
  author: string;
  date: string;
  version: string;
  licencia: string;
  tags: string[];
  description: string;
  fullText: string;
  downloads: number;
  relatedCourses: string[];
  sources: string[];
}

export interface Certificate {
  id: string;
  courseId: string;
  courseTitle: string;
  date: string;
  code: string;
  recipientName: string;
}

export interface UserProfile {
  name: string;
  email: string;
  membership: UserMembership;
  institution?: string;
  enrolledCourses: string[]; // Course IDs
  courseProgress: { [courseId: string]: number }; // percentage 0-100
  completedModules: string[]; // module IDs completed
  certificates: Certificate[];
  favorites: string[]; // Biblioteca ID favorites
}

export interface Reply {
  id: string;
  author: string;
  avatar?: string;
  content: string;
  date: string;
}

export interface CommunityPost {
  id: string;
  title: string;
  category: "General" | "Suelos" | "Biofertilizantes" | "Riego" | "Plagas" | "Casos de Éxito";
  author: string;
  content: string;
  date: string;
  likes: number;
  replies: Reply[];
}

export interface Pilar {
  id: string;
  icono: string;
  titulo: string;
  subtitulo: string;
  descripcion: string;
  temas: string[];
  color: string;
  bgColor: string;
}

export interface Mito {
  id: string;
  titulo: string;
  mito: string;
  realidad: string;
  evidencia: string;
  accion: string;
  icono: string;
  color: string;
}

export interface CasoExito {
  id: string;
  titulo: string;
  descripcion: string;
  icono: string;
  cultivo: string;
  ubicacion: string;
  resultados: string[];
}

export interface NumeroClave {
  valor: string;
  label: string;
}

export interface Receta {
  id: string;
  titulo: string;
  descripcion: string;
  ingredientes: string[];
  pasos: string[];
  tiempo: string;
  categoria: string;
  icono: string;
}

export interface GlosarioItem {
  termino: string;
  definicion: string;
}

export interface SubtemaDetalle {
  descripcion: string;
  subtemas: string[];
  icono: string;
}

export interface SubtemasMap {
  [temaNombre: string]: SubtemaDetalle;
}

