/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import Navbar from "./components/Navbar";
import HomeSection from "./components/HomeSection";
import CampusSection from "./components/CampusSection";
import BibliotecaSection from "./components/BibliotecaSection";
import AcademiaSection from "./components/AcademiaSection";
import ComunidadSection from "./components/ComunidadSection";
import RecursosSection from "./components/RecursosSection";
import InstitucionesSection from "./components/InstitucionesSection";
import PerfilSection from "./components/PerfilSection";
import AIReadySection from "./components/AIReadySection";
import { UserMembership, Certificate } from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("inicio");
  
  // Performance preferences
  const [dataSaver, setDataSaver] = useState<boolean>(() => localStorage.getItem("dataSaver") === "true");

  const handleToggleDataSaver = (val: boolean) => {
    setDataSaver(val);
    localStorage.setItem("dataSaver", String(val));
  };
  
  // User Profile state
  const [userName, setUserName] = useState<string>("Nelson Durán");
  const [userEmail, setUserEmail] = useState<string>("noslen.dur@gmail.com");
  const [userMembership, setUserMembership] = useState<UserMembership>(UserMembership.Free);
  
  // Educational progress states
  const [enrolledCourses, setEnrolledCourses] = useState<string[]>(["suelo-vivo"]);
  const [courseProgress, setCourseProgress] = useState<{ [courseId: string]: number }>({
    "suelo-vivo": 25
  });
  const [completedModules, setCompletedModules] = useState<string[]>(["sv-m1"]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [favorites, setFavorites] = useState<string[]>(["ficha-compostaje-domestico"]);

  // Extra data for handling search & deep-linking redirects
  const [extraData, setExtraData] = useState<any>(null);

  const handleNavigate = (tabId: string, data?: any) => {
    setActiveTab(tabId);
    if (data) {
      setExtraData(data);
    } else {
      setExtraData(null);
    }
    // Scroll smoothly to top
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleEnrollCourse = (courseId: string) => {
    if (!enrolledCourses.includes(courseId)) {
      setEnrolledCourses(prev => [...prev, courseId]);
      setCourseProgress(prev => ({ ...prev, [courseId]: 0 }));
    }
  };

  const handleCompleteModule = (courseId: string, moduleId: string, progressValue: number) => {
    if (!completedModules.includes(moduleId)) {
      setCompletedModules(prev => [...prev, moduleId]);
    }
    setCourseProgress(prev => ({ ...prev, [courseId]: progressValue }));
  };

  const handleAddCertificate = (cert: Certificate) => {
    setCertificates(prev => [cert, ...prev]);
  };

  const handleToggleFavorite = (docId: string) => {
    setFavorites(prev => {
      if (prev.includes(docId)) {
        return prev.filter(id => id !== docId);
      } else {
        return [...prev, docId];
      }
    });
  };

  const handleChangeProfile = (name: string, email: string, membership: UserMembership) => {
    setUserName(name);
    setUserEmail(email);
    setUserMembership(membership);
  };

  const renderActiveSection = () => {
    switch (activeTab) {
      case "inicio":
        return (
          <HomeSection 
            onNavigate={handleNavigate} 
            userName={userName}
            dataSaver={dataSaver}
          />
        );
      case "campus":
        return (
          <CampusSection 
            onNavigate={handleNavigate} 
            enrolledCourses={enrolledCourses}
          />
        );
      case "biblioteca":
        const initialSearch = extraData?.query || "";
        const selectedDocId = extraData?.docId || null;
        
        // If a direct document link was triggered, we can simulate opening it in a modal
        return (
          <BibliotecaSection 
            initialSearch={initialSearch}
            initialDocId={selectedDocId}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onNavigate={handleNavigate}
          />
        );
      case "academia":
        return (
          <AcademiaSection 
            enrolledCourses={enrolledCourses}
            courseProgress={courseProgress}
            completedModules={completedModules}
            onEnroll={handleEnrollCourse}
            onCompleteModule={handleCompleteModule}
            onAddCertificate={handleAddCertificate}
            userName={userName}
            initialCourseId={extraData?.courseId}
          />
        );
      case "comunidad":
        return (
          <ComunidadSection 
            userName={userName}
          />
        );
      case "aiready":
        return <AIReadySection />;
      case "recursos":
        return <RecursosSection />;
      case "instituciones":
        return <InstitucionesSection />;
      case "perfil":
        const completed32Courses = (() => {
          try {
            const saved = localStorage.getItem("completed_courses_32");
            return saved ? JSON.parse(saved) : [];
          } catch {
            return [];
          }
        })();
        
        let displayCerts = [...certificates];
        if (completed32Courses.length === 32 && !displayCerts.some(c => c.id === "utopia-master-cert")) {
          displayCerts.push({
            id: "utopia-master-cert",
            courseId: "utopia-master",
            courseTitle: "Especialidad Agroecológica del Modelo Utopía (32 Cursos)",
            recipientName: userName,
            date: new Date().toLocaleDateString("es-ES", { day: "numeric", month: "long", year: "numeric" }),
            code: "AA-UTOPIA-99832"
          });
        }

        return (
          <PerfilSection 
            userName={userName}
            userEmail={userEmail}
            userMembership={userMembership}
            certificates={displayCerts}
            favorites={favorites}
            onChangeProfile={handleChangeProfile}
            onNavigate={handleNavigate}
            dataSaver={dataSaver}
            onToggleDataSaver={handleToggleDataSaver}
          />
        );
      default:
        return <HomeSection onNavigate={handleNavigate} userName={userName} />;
    }
  };

  return (
    <div 
      className="min-h-screen bg-stone-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white" 
      id="app-root"
      data-data-saver={dataSaver ? "true" : "false"}
    >
      {/* Navigation */}
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        userMembership={userMembership} 
        userName={userName}
      />

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-stone-50 border border-stone-200 shadow-xs rounded-3xl p-6 sm:p-8 min-h-[600px]" id="stage-card">
          {renderActiveSection()}
        </div>
      </main>

      {/* Aesthetic simple footer */}
      <footer className="border-t border-stone-200 bg-stone-50 py-6" id="app-footer">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <p className="font-serif text-sm font-bold text-stone-900">
              Agricultura Antigua
            </p>
            <p className="text-[11px] text-stone-500">
              Preservación de saberes de la tierra y transición agroecológica científica.
            </p>
          </div>
          <div className="text-[10px] font-mono text-stone-400">
            © {new Date().getFullYear()} Agricultura Antigua. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
